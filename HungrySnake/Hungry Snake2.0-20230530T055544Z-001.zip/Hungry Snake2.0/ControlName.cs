﻿using System.Drawing;

namespace Hungry_Snake2._0
{
    internal class ControlName
    {
        public ControlName()
        {
        }

        public Color BackColor { get; internal set; }
    }
}